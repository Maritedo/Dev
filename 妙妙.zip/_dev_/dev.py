import json
def dosth():
    with open("locs.js", 'r', encoding="utf-8") as fr:
        JSON = json.loads(fr.read())
    with open("locs.json", 'w', encoding="utf-8") as f2:
        JSON2 = {x["name"]: {y["name"]: y for y in x["children"]} for x in JSON}
        for (x, y) in JSON2.items():
            for (p, q) in y.items():
                if "children" in q:
                    JSON2[x][p] = [i["name"] for i in q["children"]]
                else:
                    JSON2[x][p] = [p]
        f2.write(json.dumps(JSON2, ensure_ascii=False))

if __name__ == "__main__":
    dosth()
